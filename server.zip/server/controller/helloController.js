const HelloModel = require('../model/helloModel');

class HelloController {
  getHelloMessage(req, res) {
    const helloModel = new HelloModel();
    const message = helloModel.getMessage();
    res.json({ message });
  }
}

module.exports = HelloController;
