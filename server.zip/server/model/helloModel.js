class HelloModel {
    getMessage() {
      return "Hello World!";
    }
  }
  
module.exports = HelloModel;
  