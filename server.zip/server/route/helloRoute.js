const express = require('express');
const HelloController = require('../controller/helloController');
const helloController = new HelloController();
const router = express.Router();

router.get('/hello', helloController.getHelloMessage);

module.exports = router;
