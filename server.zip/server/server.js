const express = require('express')
const cors = require('cors');
const helloRoute = require('./route/helloRoute');

const app= express()

app.use(cors());

const PORT = process.env.Port || 3002

app.listen(PORT,()=>{
    console.log(`Server is running ${PORT}`)
})
 app.use('/', helloRoute)